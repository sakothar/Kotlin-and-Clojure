import java.util.Scanner
fun isPerfectNum(num:Int): Boolean
{
    var tmp=0
    for(x in 1..num / 2){
        if(num%1==0){
            tmp += x
        }
    }
    if(tmp==num)
    {
        println("Perfect Number")
        return true
    }else{
        println("Not Perfect Number")
        return false
    }
}

fun main(a: Array<String>)
{
    var n:Int = 0
    val reader= Scanner(System.`in`)
    println("Enter Starting value:")
    var x: Int=reader.nextInt()
    println("Enter Ending value:")
    var y: Int=reader.nextInt()
    while (x!=y)
    {
        n=x
        println("Given Number is"+n)
        println("is Perfect Number" +isPerfectNum(n))
        x=x+1
    }
}
