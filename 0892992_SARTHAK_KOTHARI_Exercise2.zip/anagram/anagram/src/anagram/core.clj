(ns anagram.core
  [:require [clojure.string :as str]])

(defn anagram? [word possible-anagram]
  (and 
    (not= word possible-anagram)
    (= (sort possible-anagram)
       (sort word))))

(defn case-insensitive-anagram? [word possible-anagram]
  (anagram? 
    (str/lower-case word) 
    (str/lower-case possible-anagram)))

(defn anagrams-for [word dictionary]
  (vec 
    (println(filter #(case-insensitive-anagram? word %) dictionary))))
    
(def word "alcan")
(def word1 "lal")
(def word2 "neev")

(def dictionary ["indicatory", "apple", "canal", "cat", "bat" , "dog", "elephant", "a", "about", "all", "also", "and", "as", "at", "be", "because", "but", "by", "can", "come", "could", "day", "do", "even", "find", "first", "for", "from", "get", "give", "go", "have", "he", "her", "here", "him", "his", "how", "I", "if", "in", "into", "it", "its", "just", "know", "like", "look", "make", "man", "many", "me", "more", "my", "new", "no", "not", "now", "of", "on", "one", "only", "or", "other", "our", "out", "people", "say", "see", "she", "so", "some", "take", "tell", "than", "that", "the", "their", "them", "then", "there", "these", "they", "thing", "think", "this", "those", "time", "to", "two", "up", "use", "very", "want", "way", "we", "well", "what", "when", "which", "who", "will", "with", "would", "year", "you", "your", "Acquiesce", "Acronym", "Ambiguity", "Analogy", "Anachronism", "Andragogy", "Antithesis", "Antonym", "Articulate", "Assonance", "Benchmarking", "Brainstorming", "Circumspect", "Clandestine", "Cognition", "Collaborate", "Colloquial", "Connotation", "Contrived", "Conundrum", "Correlation", "Criterion", "Cumulative", "Curriculum", "Deference", "Developmental", "Dialect", "Diction", "Didactic", "Dissertation", "Divergent", "Egregious", "Eloquence", "Emergent", "Empathy", "Enigma", "Epitome", "Epiphany", "Epitaph", "Erudite", "Existential", "Exponential", "Formative", "Holistic", "Homonym", "Hubris", "Hyperbole", "Incongruous", "Infamy", "Initiation", "Innate", "Intellectual", "Interactive", "Irony", "Jargon", "Juxtaposition", "Malapropism", "Magnanimous", "Mentor", "Metaphor", "Meticulous", "Mnemonic", "Monologue", "Motif", "Myriad", "Nemesis", "Nominal", "Norms", "Obfuscate", "Obtuse", "Onomatopoeia", "Ostentatious", "Oxymoron", "Paradox", "Paraphrase", "Pedantic", "Pedagogy", "Perusal", "Phonemes", "Phonological", "Plagiarism", "Plethora", "Posthumously", "Preposition", "Pretentious", "Pseudonym", "References", "Reflection", "Rubric", "Sardonic", "Satire", "Simile", "Soliloquy", "Superfluous", "Syntax", "Thesis", "Validity", "Vernacular", "Virtual", "Vocational"])

(defn -main []
  (anagrams-for word dictionary)
  (anagrams-for word1 dictionary)
  (anagrams-for word2 dictionary))    
