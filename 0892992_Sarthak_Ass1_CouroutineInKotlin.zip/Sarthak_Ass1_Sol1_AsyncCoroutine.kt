import kotlinx.coroutines.*
import java.lang.Thread
import kotlin.system.measureTimeMillis

fun main(args: Array<String>) = runBlocking {
    val time = measureTimeMillis {
        val first = async { firstNumber() }
        val second = async { secondNumber() }
        val third = async { thirdNumber() }

        val result = first.await() + second.await() + third.await()
    }

    println(time) //prints 7 seconds
}
suspend fun firstNumber(): Int {
    delay(3_000)
    println("Starting first match")// 3 seconds delay

    println("Finishing first match")// 3 seconds delay
    return 5
}
suspend fun secondNumber(): Int {
    delay(5_000) // 5 seconds delay
    println("Starting Second match")// 3 seconds delay
    println("Finishing Second match")// 3 seconds delay
    return 8
}
suspend fun thirdNumber(): Int {
    delay(7_000) // 7 seconds delay
    println("Starting Third match")// 3 seconds delay
    println("Finishing Third match")// 3 seconds delay
    return 10
}

package kotlinx.coroutines.guide.channel01
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.*

fun main() = runBlocking {
    val channel = Channel<Int>()
    launch {
        // this might be heavy CPU-consuming computation or async logic, we'll just send five squares
        for (x in 1..5) channel.send(x * x)
    }
    // here we print five received integers:
    repeat(5) { println(channel.receive()) }
    println("Done!")
}



