package com.sarthak

interface Item {
  val weight: Int
}
