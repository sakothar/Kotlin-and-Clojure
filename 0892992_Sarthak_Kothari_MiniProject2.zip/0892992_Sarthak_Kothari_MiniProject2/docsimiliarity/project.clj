(defproject docsimiliarity "0.0.1-SNAPSHOT"
  :description "FIXME: write description"
  :dependencies [[org.clojure/clojure "1.9.0"]]
  :aot [docsimiliarity.core]
  :main docsimiliarity.core)
